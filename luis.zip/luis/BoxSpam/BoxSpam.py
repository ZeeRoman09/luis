#pylint:disable=E0001
#pylint:disable=E0001
#!/usr/bin/python2
# Xeit666h05t
# Author: Xeit666h05t
# Email:xeitcyber@gmail.com
# Team: CoiZter_Team
# Hargai CopyRight Ya Bila Ingin Di Hargai
#*/kalau mau di hargain Hargai Copyright Yang Bikin
import os
import base64

os.system("clear")

print """     
_______                        ______                                    
/       \                      /      \                                   
$$$$$$$  |  ______   __    __ /$$$$$$  |  ______    ______   _____  ____  
$$ |__$$ | /      \ /  \  /  |$$ \__$$/  /      \  /      \ /     \/    \ 
$$    $$< /$$$$$$  |$$  \/$$/ $$      \ /$$$$$$  | $$$$$$  |$$$$$$ $$$$  |
$$$$$$$  |$$ |  $$ | $$  $$<   $$$$$$  |$$ |  $$ | /    $$ |$$ | $$ | $$ |
$$ |__$$ |$$ \__$$ | /$$$$  \ /  \__$$ |$$ |__$$ |/$$$$$$$ |$$ | $$ | $$ |
$$    $$/ $$    $$/ /$$/ $$  |$$    $$/ $$    $$/ $$    $$ |$$ | $$ | $$ |
$$$$$$$/   $$$$$$/  $$/   $$/  $$$$$$/  $$$$$$$/   $$$$$$$/ $$/  $$/  $$/ 
                                        $$ |                              
                                        $$ |                              
                                        $$/                                                      
BoxSpam V.1{Beta} 
Source Code : Python                                   
Date  : 06-03-2018
Author : Luis Greysia     
Team : RomanTeam                                 
Note : Di Praktiskan Menjadi 5 Tools
1 Tools Masing Masing Memiliki Beberapa Tools Di Dalamnya Agar Lebih Praktis Saja 
"""
print "----------------------------------"
print "1).Spammer"
print "2).RAT"
print "3).Brute Force"
print "4).Auto Installer"
print "5).ExitZ"
xeit666h05t=raw_input("\nBoxSpam>>>")

if xeit666h05t == '1':
	print "1).LITESpam"
if xeit666h05t == '2':
	print "01).TheFatRat"
	print "02).LolZ_Rat"
if xeit666h05t == '3':
	print "001).Wordpress Brute Force"
	print "002).Fbbrute"
	print "003).Gmail Brute Force"
if xeit666h05t == '4':
	print "0001).BoxCoder"
	print "0002).BoxCoderV.2"
	print "0003).BoxServer"
	print "0004).LazyMux"
if xeit666h05t == '5':
	print ("Mau Kemana Sih Buru Buru Amat:v")
	print "Thanks All Mem CoiZter_Team"
	print "ShootZ Ghozt666h05t"
	print "XEIT_Cyber - Z#Sec - ./Mr ID"
	print "Lazy Time - Mr.-12cb - Mr.Han - Mr.Hellme - M.r EXe"
	print "GOODBLIZE - DISCONNECT - Mr.4r7Hu12 - Mr.Zin3_Xpl0it - F4ILURE_ID - Epp666h05t - 777GRxZH05T - X999ZploitX - ./XeitGhost - Mr.ZKi And All Mem CoiZter_Team"
	print "Bye Bye:*"

xeit666h05t=raw_input("\nBoxSpam>>>")

if xeit666h05t =='1':
	print " Install LITESpam"
	os.system("apt-get upgrade")
	os.system("pkg install git")
	os.system("pkg install php")
	os.system("pkg install bash")
	os.system("git clone https://github.com/4L13199/LITESPAM.git")
	os.system("clear")
	print "Terinstall"
	
if xeit666h05t =='01':
	print "Install The FatRat"
	os.system("apt-get update && apt-get upgrade")
	os.system("apt-get install git")
	os.system("git clone https://github.com/Screetsec/TheFatRat.git")
	os.system("cd TheFatRat")
	os.system("chmod +x setup.sh && ./setup.sh")
	os.system("clear")
	
if xeit666h05t == '02':
	print "Install LolZ_Rat"
	os.system("pkg install php")
	os.system("pkg install git")
	os.system("git clone https://github.com/mrcakil/Lolz_RAT")
	os.system("cd Lolz_RAT")
	os.system("chmod +x Lolz_RAT1")
	os.system("clear")
	
if xeit666h05t == '001':
	print "Install Wordpress Brute"
	os.system("apt-get update && apt-get upgrade")
	os.system("apt-get install python2")
	os.system("pip install request")
	os.system("git clone https://github.com/atarantini/wpbf")
	os.system("clear")
	
if xeit666h05t == '002':
            print("Install Facebook BruteForce")
            os.system("pkg update && pkg upgrade")
            os.system("pkg upgrade")
            os.system("pkg update")
            os.system("pkg install git")
            os.system("apt install python2-dev")
            os.system("pkg install python")
            os.system("apt install wget")
            os.system("pip2 install mechanize")
            os.system("git clone https://github.com/DaffaTakarai/XEIT_Cyber")
            os.system("clear")
    
if xeit666h05t == '003':
	print "install Gmail Brute Force"
	os.system("apt-get update && apt-get upgrade")
	os.system("apt-get install git")
	os.system("git clone https://github.com/JamesAndresCM/Brute_force_gmail")
	os.system("clear")
	
if xeit666h05t == '0001':
	print "Install BoxCoder"
	os.system("pkg update")
	os.system("pkg upgrade")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("git clone https://github.com/Xeit666h05t/BoxCoder")
	os.system("clear")
	
if xeit666h05t == '0002':
	print " Install BoxCoderV.2"
	os.system("pkg update")
	os.system("pkg upgrade")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("git clone https://github.com/Xeit666h05t/BoxCoderV.2")
	os.system("clear")
	
if xeit666h05t == '0003':
	print "Install BoxServer"
	os.system("pkg update")
	os.system("pkg upgrade")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("git clone https://github.com/Xeit666h05t/BoxServer")
	os.system("clear")
	
if xeit666h05t == '0004':
    print "Install Lazymux"
    os.system("apt upgrade")
    os.system("apt update")
    os.system("pkg install python2")
    os.system("pkg install git")
    os.system("git clone https://github.com/Gameye98/lazymux.git")
    os.system("clear")
    
