# LITESPAM
Berisi Tools Spammer Dengan Berbagai Macam jenis Dengan Limit Tinggi Bahkan Diperkirakan Unlimited Dibangun Atas Segala Kontribusi Coders Untuk Mengumpulkan Tools Nya Disini, Dengan Spam Tidak Menjadikan mu Hackers, Cyber, Cracker, Anonymous Dan Antek Anteknya. Spamming Hanya Untuk Tujuan Baik Tidak Melanggar Hukum Dan Aturan Agama

# INSTALASI
```
$ pkg update upgrade
$ pkg install git python2 toilet figlet php
$ git clone https://github.com/4L13199/LITESPAM
$ cd LITESPAM
```
# PERINGATAN
KAMI HANYA MENYEDIAKAN TOOLS UNTUK TUJUAN KEBAIKAN BUKAN DISALAHKAN GUNAKAN UNTUK MENJAHILI SESEORANG
SEGALA SESUATU DI TANGGUNG PENGGUNA

