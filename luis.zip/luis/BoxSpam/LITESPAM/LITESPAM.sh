#!/system/xbin/bash
clear
git clone https://github.com/amsitlab/smsid-java.git
cd ./smsid-java
chmod +x ./install
apt install ./smsid_1.1_all.deb
clear

toilet -f slant --gay "LiteSpam"
sleep 1
echo "\033[33;1m Macam-macam tool untuk spam"
sleep 1
echo "\033[36;1m★""\033[34;1mIndonesia Security Lite""\033[36;1m★"
sleep 1
echo "\033[32;1m Spam Yang Tersedia :"
echo "\033[35;1m1.""\033[36;1mBukalapak"
echo "\033[35;1m2.""\033[36;1mTelkomsel"
echo "\033[35;1m3.""\033[36;1mGrab"
echo "\033[35;1m4.""\033[36;1mTokopedia"
echo "\033[35;1m5.""\033[36;1mCodaShop"
echo "\033[35;1m6.""\033[36;1mSurveyon"
echo "\033[35;1m7.""\033[36;1mCustom"
echo "\033[31;1m0. Keluar"
echo "\033[37;1m81.""\033[30;1mInformasi Tool Ini"
echo "\033[33;1m Pilih Angka:"
read mrrm

if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
toilet -f slant "Bukalapak"
echo "\033[31;1mJenis Spam:""\033[37;1mChat WhatsApp"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mSGB-Team"
sleep 5
clear
cd $HOME/LITESPAM/Tul/
php 1
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
echo "\033[31;1m"
toilet "T-Sel"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mDanz"
sleep 5
clear
cd $HOME/LITESPAM/Tul/
php 2.php
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
echo "\033[36;1m"
figlet "Grab"
echo "\033[31;1mJenis Spam:""\033[37;1mTelepon"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mRaja Adtiya Candra"
sleep 5
clear
cd $HOME/LITESPAM/Tul/
php 3.php
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono9 -F gay "Toked"
echo "\033[31;1mJenis Spam:""\033[37;1mTelepon"
echo "\033[31;1mBatas:""\033[37;1m1 Kali"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mSGB-Team"
sleep 5
clear
cd $HOME/LITESPAM/Tul/
php 4.php
fi

if [ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f slant -F gay "CodaShop"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mBullyHat"
echo
echo
echo "\033[33;1mCOPY LISENSI INI:" "\033[36;1mJDJ5JDEwJC9YMWRvNC5jcmNOSUw2dGdUaUt2d08ucWEvWURWSFNCTXI3U21wdkdsR1FMcVBSTW1oNUZH"
sleep 1
echo "\033[32;1mtunggu 5 Detik"
sleep 5
clear
cd $HOME/LITESPAM/Tul/
php 5.php
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Surveyon "
echo "\033[31;1mJenis Spam:""\033[37;1mEmail"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mphp"
echo "\033[31;1mAuthor:""\033[37;1mChandra Aditya"
sleep 5
cd $HOME/LITESPAM/Tul/
php 6.php
fi

if
[ $mrrm = 7 ] || [ $mrrm = 7 ]
then
clear
toilet -f slant --gay "SMSID"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1m5"
echo "\033[31;1mPemograman:""\033[37;1mBerjalan Langsung Pada DalvikVM"
echo "\033[31;1mAuthor:""\033[37;1mAmsitlab"
echo
echo
echo "\033[33;1mInformasi Lebih Lanjut Kunjungi:""\033[36;1mhttps://amsitlab.github.io/smsid-java/"
sleep 6
smsid boom -y
fi

if
[ $mrrm = 81 ] || [ $mrrm = 81 ]
then
clear
toilet -f slant --gay "LiteSpam"
echo "\033[34;1mContact:""\033[37;1m https://fb.me/IrsyadMaulana81"


sleep 1
echo "\033[35;1mPemograman:""\033[36;1m Bash"

echo "\033[33;1mKarya: IM81"
sleep 1
echo "\033[32;1mVersi: v3"
sleep 1
echo "\033[36;1mTeam: Indonesia Security Lite"
sleep 1
echo "\033[31;1mSubscribe YouTube""\033[37;1m HeXeRz"
echo "\033[35;1m Spesial Thanks To: "
echo "\033[36;1m"
echo "Danz"
echo "Mr.Rm"
echo "SBGTeam"
echo "amsitlab"
echo "Bully Hat"
echo "ChandraAditya"
echo "Secoly Indonesia"
echo "BlackHole Security"
echo "Association Indonesian Right Wings"
sleep 1
echo "And All Member Indonesia Security Lite"
echo "\033[30;1m tunggu 8 detik"
sleep 8
sh LITESPAM.sh
fi



if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "\033[31;1m Keluar"
sleep 1
echo "\033[32;1m Sampai berjumpa lagi :)"
sleep 1
fi

