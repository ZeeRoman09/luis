#pylint:disable=E0001
#pylint:disable=E0001
#!/usr/bin/python2
# Xeit666h05t
# Author: Xeit666h05t
# Email:xeitcyber@gmail.com
# Team: CoiZter_Team
# Hargai CopyRight Ya Bila Ingin Di Hargai
#*/kalau mau di hargain Hargai Copyright Yang Bikin
import os
import base64

os.system("clear")

print """     
__________                _________                               .___
\______   \ _______  ___ /   _____/ ____  ______ _____   ____   __| _/
 |    |  _//  _ \  \/  / \_____  \ /  _ \/  ___//     \_/ __ \ / __ | 
 |    |   (  <_> >    <  /        (  <_> )___ \|  Y Y  \  ___// /_/ | 
 |______  /\____/__/\_ \/_______  /\____/____  >__|_|  /\___  >____ | 
        \/            \/        \/           \/      \/     \/     \/ 
BoxSosmed V.1{Beta} 
Source Code : Python                                   
Date  : 10-03-2018
Author : Xeit666h05t     
Team : CoiZter_Team                                 
Note : Tools Sosmed Seperti InstaHack DLL
"""
print "----------------------------------"
print "1).Instagram Privat Tools"
print "2).Fb Reaction"
print "3).Weeman"
print "4).InstaHack"
print "5).Wordpress Brute Force"
print "6).Bot"
print "7).Line Bot"
print "8).Red Widow Spider Tools"
print "9).Line BotKick"
print "10).Line Bot Self"
print "99).ExitZ"
xeit666h05t=raw_input("\nBoxSosmed>>>")
if xeit666h05t == '1':
	print "Install Instagram Privat Tools"
	os.system("apt update && apt upgrade -y")
	os.system("apt install nodejs git")
	os.system("cd Instagram-Private-Tools")
	os.system("node index.js")
	os.system("git clone https://github.com/ccocot/Instagram-Private-Tools.git")
	os.system("npm install")
	os.system("clear")
	print "Done Mamank:v"
	
if xeit666h05t == '2':
	print "Install FbReaction"
	os.system("apt update && apt upgrade -y")
	os.system("apt instal git php curl -y")
	os.system("git clone https://github.com/AMVengeance/FB-React.git")
	os.system("cd FB-React")
	os.system("chmod +x start")
	print "Done Mamank:v"
	
if xeit666h05t == '3':
	print "Install Weeman"
	os.system("pkg update && pkg upgrade")
	os.system("pkg install python")
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("git clone https://github.com/samyoyo/weeman")
	os.system("ls")
	os.system("chmod +x weeman")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '4':
	print "Install InstaHack"
	os.system("apt update && apt upgrade")
	os.system("apt install python2 -y")
	os.system("apt install git -y")
	os.system("git clone https://github.com/avramit/instahack/ ighack/")
	os.system("cd ighack")
	os.system("pip2 install requests")
	os.system("mv hackinsta.py main.py")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '5':
	print ("Install Wordpress Brute Force")
	os.system("apt-get update && apt-get upgrade")
	os.system("apt-get install python2")
	os.system("pip install request")
	os.system("git clone https://github.com/atarantini/wpbf")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '6':
	print "Install Bot"
	os.system("apt-get update && apt-get upgrade")
	os.system("apt-get install git")
	os.system("apt-get install wget")
	os.system("apt-get install perl")
	os.system("apt-get install unzip")
	os.system("git clone https://github.com/mrcakil/bot.git")
	os.system("cd bot")
	os.system("unzip bot.zip")
	os.system("cd xploit")
	os.system("chmod 777 bot.pl")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '7':
	print "Install Line Bot"
	os.system("apt-update && apt-upgrade")
	os.system("pkg install git")
	os.system("git clone http://github.com/merkremont/LineVodka")
	os.system("pip2 install thrift==0.9.3")
	os.system("pkg install rsa")
	os.system("pip2 install requests")
	os.system("pip2 install rsa")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t =='8':
	print "Red Widow Spider Tools"
	os.system("apt install git")
	os.system("git clone https://github.com/Bhai4You/RWST")
	os.system("cd RWST")
	os.system("cd bash")
	os.system("chmod +x requirement.sh")
	os.system("bash requirement.sh")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '9':
	print "Install Line Bot Kick"
	os.system("pkg install python2")
	os.system("pkg install git")
	os.system("pkg install nano")
	os.system("git clone https://github.com/alfathdirk/LIN3-TCR")
	os.system("pip2 install rsa")
	os.system("pip2 install thrift==0.9.3")
	os.system("pip2 install requests")
	os.system("clear")
	print "Done Mamanx:v"
	
if xeit666h05t == '10':
	print "Install Line Bot Self"
	os.system("pkg install python2")
	os.system("pip2 install rsa")
	os.system("pip2 install requests")
	os.system("pip2 install thrift==0.9.3")
	os.system("pkg install git")
	os.system("pkg install nano")
	os.system("git clone github.com/TobyG74/BotToby")
	os.system("clear")
	
if xeit666h05t == '99':
	print "Thanks All Mem CoiZter_Team"
	print "Thanks To Ghozt666h05t - XEIT_Cyber - Z#Sec - ./Mr ID"
	print "Lazy Time - Mr.-12cb - Mr.Han - Mr.Hellme - M r.EXe"
	print "GOODBLIZE - DISCONNECT - Mr.4r7Hu12 - Mr.Zin3_Xpl0it - F4ILURE_ID - Epp666h05t - 777GRxZH05T - X999ZploitX - ./XeitGhost - Mr.ZKi And All Mem CoiZter_Team"
	print "Bye Bye :*"
	


    
