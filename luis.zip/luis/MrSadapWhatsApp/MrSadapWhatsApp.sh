#!/usr/bin/bash
#Tools SadapWhatsApp
#Sadap WhatsApp
#By MrTamfanX 
#Jangan DiRecord Tod!!!
#Bersihkan Layar
clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
echo " "
echo  $blue "<|======================================|>"
echo  $blue "<|            Tools SadapWhatsApp       |>"
echo  $blue "<|                                      |>"
echo  $blue "<| Name: Zee Roman    ||    Zee Roman   |>"
echo  $blue "<| MyTeam: Roman Team                   |>"
echo  $blue "<| Contact: +6285349370423              |>"
echo  $blue "<| Thanks To:  GOD[ALLAH]               |>"
echo  $blue "<|======================================|>"
sleep 1
echo  $red "============== $red MENU $green ================="
echo $blue "================================================="
echo $blue "|| $green 1. Sadap WhatsApp No Indosat   $blue ||"
echo $blue "|| $green 2. Sadap WhatsApp No Telkomsel $blue ||"
echo $blue "|| $green 3. Sadap WhatsApp No XL / Axis $blue ||"
echo $blue "|| $green 4. Sadap WhatsApp No 3(Three)  $blue ||"
echo $blue "|| $green 0. Exit Sadap WhatsApp         $blue ||"
echo $blue "================================================="
echo $blue"╭──[Masukkan Pilihan Anda]>"
read -p"╰───────root@ZeeRoman=•>" ZeeRoman;
if [ $ZeeRoman = 1 ] || [ $ZeeRoman = 01 ]
then
echo $blue"╭──[Silahkan Masukan Nomernya]>"
read -p"╰───────root@ZeeRoman=•>" ZeeRoman;
sleep 2
echo $red "[+]Scaning...."
sleep 3
echo $blue "10%"
sleep 4
echo $green "20%"
sleep 2
echo $cyan "30%"
sleep 8
echo $purple "40%"
sleep 3
echo $blue "50%"
sleep 2
echo $red "60%"
sleep 5
echo $green "70%"
sleep 6
echo $cyan "80%"
sleep 7
echo $purple "90%"
sleep 3
echo $blue "100%"
sleep 2
echo $green "Prosessing Done"
sleep 4
echo  $blue "Nomer WhatsApp Berhasil Di Sadap $Verifikasi"
fi

if [ $ZeeRoman = 2 ] || [ $ZeeRoman = 02 ]
then
echo $blue"╭──[Silahkan Masukan Nomernya]>"
read -p"╰───────root@ZeeRoman=•>" ZeeRoman;
sleep 2
echo $red "[+]Scaning...."
sleep 5
echo $blue "10%"
sleep 3
echo $green "20%"
sleep 8
echo $cyan "30%"
sleep 3
echo $purple "40%"
sleep 6
echo $blue "50%"
sleep 5
echo $red "60%"
sleep 4
echo $green "70%"
sleep 6
echo $cyan "80%"
sleep 8
echo $purple "90%"
sleep 6
echo $blue "100%"
sleep 9
echo $green "Prosessing Done"
sleep 3
echo  $blue "Nomer WhatsApp Berhasil Di Sadap $Verifikasi"
fi

if [ $ZeeRoman = 3 ] || [ $ZeeRoman = 03 ]
then
echo $blue"╭──[Silahkan Masukan Nomernya]>"
read -p"╰───────root@ZeeRoman=•>" ZeeRoman;
sleep 2
echo $red "[+]Scaning...."
sleep 8
echo $blue "10%"
sleep 4
echo $green "20%"
sleep 5
echo $cyan "30%"
sleep 6
echo $purple "40%"
sleep 4
echo $blue "50%"
sleep 2
echo $red "60%"
sleep 3
echo $green "70%"
sleep 9
echo $cyan "80%"
sleep 7
echo $purple "90%"
sleep 4
echo $blue "100%"
sleep 9
echo $green "Prosessing Done"
sleep 9
echo  $blue "Nomer WhatsApp Berhasil Di Sadap $Nomer $Kode Verifikasi"
fi

if [ $ZeeRoman = 4 ] || [ $ZeeRoman = 04 ]
then
echo $blue"╭──[Silahkan Masukan Nomernya]>"
read -p"╰───────root@ZeeRoman=•>" ZeeRoman;
sleep 2
echo $red "[+]Scaning...."
sleep 8
echo $blue "10%"
sleep 7
echo $green "20%"
sleep 5
echo $cyan "30%"
sleep 4
echo $purple "40%"
sleep 5.5
echo $blue "50%"
sleep 4
echo $red "60%"
sleep 5
echo $green "70%"
sleep 6
echo $cyan "80%"
sleep 7
echo $purple "90%"
sleep 5
echo $blue "100%"
sleep 3
echo $green "Prosessing Done"
sleep 4
echo  $blue "Nomer WhatsApp Berhasil Di Sadap $Nomer $Kode Verifikasi"
fi

if [ $ZeeRoman = 0 ] || [ $ZeeRoman = 00 ]
then
echo  $red "Bye Bye Sayang"
echo  $blue "Jangan Lupa Harus Ngeue Kalo Bisa!"
echo  $green "Thaks To Roman Team!"
exit
fi

