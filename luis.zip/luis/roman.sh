clear
#!/system/bin/sh

echo "\033[1;93m=================="
echo "\033[1;93m  SELAMAT DATANG"
echo "\033[1;93m==================" 
echo ""
echo "==Masukan Nama Anda=="
sleep 2
read nama
echo "==HALLO $nama=="
sleep 2
echo "❤selamat datang yea $nama khamvhank❤"
sleep 5

clear
echo "\033[1;91m█████████"
echo "\033[1;91m█▄█████▄█      ●▬▬▬▬▬▬▬▬▬๑۩۩๑▬▬▬▬▬▬▬▬●"
echo "\033[1;91m█ ▲▲▲▲▲              Zee Roman"
echo "\033[1;91m█ ▲▲▲▲▲        «----------✧----------"»
echo "\033[1;91m█████████   SUBSCRIBE NOW TO MY CHANNELL !!"
echo "\033[1;91m ██ ██           script  byZee Roman"
echo "\033[1;93m╔════════════════════════════════════════╗"
echo "\033[1;93m║\033[1;96m¤ \033[1;93mAuthor  \033[1;93m: \033[1;93mLuis Greysia  \033[1;93m              ║"
echo "\033[1;93m║\033[1;96m¤ \033[1;93mWa  \033[1;93m    :  \033[1;93m\033[4m085349370423\033[0m \033[1;93m              ║"
echo "\033[1;93m╚════════════════════════════════════════╝"

sleep 3

echo " \033[1;93msilahkan pilih nomor"
sleep 2
echo "\033[1;93m[ 01 ]Sadap WhatsApp
\033[1;93m[ 02 ]Spam Email
\033[1;93m[ 03 ]Dark fb
\033[1;93m[ 04 ]Hack FB Anti [CP]
\033[1;93m[ 05 ]BOT FACEBOOK
\033[1;93m[ 06 ]TERKEY
\033[1;93m[ 07 ]TAMPILAN TERMUX KEREN
\033[1;93m[ 08 ]SPAM SMS
\033[1;93m[ 09 ]BoxSosmed
\033[1;93m[ 10 ]BOXspam
\033[1;93m[ 11 ]script DEFACE keren
\033[1;93m[ 00 ]exit"
echo "\033[1;97m[+]PILIH NOMOR>>>"
read nomor

if [ $nomor = 01 ] || [ $nomor = 01 ]
then
clear
echo "WAIT... INSTALL  BAHAN" | lolcat
sleep 2
apt update && apt upgrade
apt install ruby
apt install bash
apt install git
git clone https://github.com/MrTamfanX/MrSadapWhatsApp
cd  MrSadapWhatsApp
chmod +x *
sh MrSadapWhatsApp.sh
fi

if [ $nomor = 02 ] || [ $nomor = 02 ]
then
clear
echo "WAIT... INSTALL BAHAN" | lolcat
sleep 2
git clone https://github.com/FttyFy/Spmail
cd Spmail
php spmail.php
fi

if [ $nomor = 03 ] || [ $nomor = 03]
then
clear
echo "WAIT... INSTALL BAHAN" | lolcat
sleep 2
apt update && apt upgrade
pkg install git
pkg install python2
git clone https://github.com/storiku/darkfb
pip2 install requests
pip2 install mechanize
echo "WAIT..." | lolcat
sleep 2
echo "MEMBUKA TOOLS..." | lolcat
cd darkfb
python2 Dark.py
fi

if [ $nomor = 04 ] || [ $nomor = 04 ]
then
clear
echo "WAIT... INSTALL  MODULE" | lolcat
apt update
apt upgrade
echo "WAIT... INSTALL  PYTHON" | lolcat
apt-get install python
echo "WAIT... INSTALL  PYTHON2" | lolcat
apt install python2
echo "WAIT... INSTALL  REQUESTS" | lolcat
pip2 install requests
echo "WAIT... INSTALL  MECHANIZE" | lolcat
pip2 install mechanize
echo "WAIT... INSTALL  UPGRADE PIP" | lolcat
pip2 install --upgrade pip
echo "WAIT... INSTALL  UPGRADE GIT CLONE" | lolcat
pkg install git -y
echo "WAITING INSTALL SCRIPT FBv3" | lolcat
cd FBv3
python2 fbv3.py
fi

if [ $nomor = 05 ] || [ $nomor = 05 ]
then
clear
echo "WAIT... " | lolcat
cd BOT
sleep 2
echo "MEMBUKA..." | lolcat
sleep 3
python2 blackbot.py
fi

if [ $nomor = 06 ] || [ $nomor = 06]
then
clear
echo "WAIT..." | lolcat
sleep 2
echo "SEDANG MASUK..." |lolcat
sleep 2
echo "BERHASIL MASUK" | lolcat
sleep 2
cd terkey
python2 terkey.py
fi

if [ $nomor = 07 ] || [ $nomor = 07 ]
then 
clear
echo "PLEASE WAIT..." | lolcat
sleep 2
echo "10%" | lolcat
sleep 2
echo "20%" | lolcat
sleep 4
echo "30%" | lolcat
sleep 1
echo "40%" | lolcat
sleep 3
echo "50%" | lolcat
sleep 3
echo "60%" | lolcat
sleep 5
echo "70%" | lolcat
sleep 1
echo "80%" | lolcat
sleep 1
echo "90%" | lolcat
sleep 3
echo "100%" | lolcat
sleep 2
echo "SEDANG MASUK..." | lolcat
sleep 3
echo "==BERHASIL MASUK=="
sleep 3
cd termux-ohmyzsh
sh install.sh
fi

if [ $nomor = 08 ] || [ $nomor = 08 ]
then
clear
echo "PROSES..." | lolcat
sleep 2
echo "BERHASIL MASUK" | lolcat
sleep 4
cd ANRspam
sh ANR.sh
fi

if [ $nomor = 09 ] || [ $nomor = 09 ]
then
clear
echo "WAIT..." | lolcat
sleep 3
echo "SEDANG MEMBUKA..." | lolcat
sleep 5
echo "Berhasil!!!" | lolcat
sleep 3
cd BoxSosmed
python2 BoxSosmed.py
fi

if [ $nomor = 10 ] || [ $nomor = 10 ]
then
clear
echo "WAIT..." | lolcat
sleep 3
echo "LOADING..." | lolcat
echo "10%" | lolcat
sleep 3
echo "20%" | lolcat
sleep 2
echo "30%" | lolcat
sleep 1
echo "50%" | lolcat
sleep 2
echo "80%" | lolcat
sleep 3
echo "99%" | lolcat
sleep 4
echo "100%" | lolcat
sleep 2
echo "SEDANG MASUK..." | lolcat
sleep 3
clear
echo "SILAHKAN TUNGGU 5 DETIK" | lolcat
sleep 5
clear
echo "1..." | lolcat
sleep 2
clear
echo "2..." | lolcat
sleep 2
clear
echo "3..." | lolcat
sleep 2
clear
echo "4..." | lolcat
sleep 2
clear
echo "5..." | lolcat
sleep 2
clear
sleep 1
echo "SEDANG MASUK..." | lolcat
sleep 2
clear
echo "BERHASIL MASUK" | lolcat
sleep 3
cd BoxSpam
python2 BoxSpam.py
fi

if [ $nomor = 11 ] || [ $nomor = 11 ]
then
clear
echo "WAIT...INSTALL MODULE" | lolcat
sleep 1
apt update && apt upgrade
sleep 1
echo "WAIT...INSTALL python" | lolcat
sleep 1
pkg install python2
sleep 1
echo "WAIT...INSTALL git" | lolcat
sleep 1
pkg install git
sleep 1
echo "WAIT...INSTALL GitHub" | lolcat
sleep 1
git clone https://github.com/Ubaii/Script-Deface-Creator
sleep 1
echo "WAIT..." | lolcat
cd Script-Deface-Creator
chmod +x create.py
sleep 2
echo "MEMBUKA..." | lolcat
sleep 2
echo "BERHASIL MASUK" | lolcat
python2 create.py
sleep 3
fi

if [ $nomor = 00 ] || [ $nomor = 00 ]
then
clear
echo "TERIMA KASIH SUDAH MENGGUNAKAN TOOLS KAMI" | lolcat
sleep 2
echo "BYE SAYANG"
sleep 3
clear
sleep 1
echo "SEDANG KELUAR..." || lolcat
sleep 3
clear
login
fi

